#!/bin/sh
./server
echo "Application Started on Port 8000"
