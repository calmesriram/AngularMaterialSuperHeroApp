# SuperHeroApp

SuperHeroApp describes about, Each and every character present in the Marvel's history, Developed on top of Mongoose C++ web server.

1. Set ninja in PATH.

2. To build the Server, Goto "src" dir and run the below command: -> ninja

3. To run the Server: -> sh run.sh

4. Server will run on port 8000.
